/* Small, dependency-free static-site renderer. All text is inserted as text, not HTML.
   THIS DOES NOT PREVENT COPYING. It prevents publishing editable originals by design. */
(function () {
  'use strict';
  const q = new URLSearchParams(window.location.search);
  const categories = window.PORTFOLIO || {};

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (typeof text === 'string') node.textContent = text;
    return node;
  }
  function appendText(parent, tag, className, text) {
    if (typeof text === 'string' && text.trim()) parent.appendChild(el(tag, className, text));
  }
  function empty(target, heading, message) {
    const box = el('div', 'empty-state');
    box.appendChild(el('h2', '', heading));
    box.appendChild(el('p', '', message));
    target.appendChild(box);
  }
  function imageAllowed(path, type) {
    // A data-file mistake should never turn into a link to original PDFs.
    const rule = type === 'resume'
      ? /^assets\/resume\/[a-z0-9_\-]+\.(webp|png|jpe?g)$/i
      : /^assets\/previews\/[a-z0-9_\-]+\/[a-z0-9_\-]+\.(webp|png|jpe?g)$/i;
    return typeof path === 'string' && rule.test(path);
  }
  function previewGallery(target, paths, captionBase, type) {
    const safe = Array.isArray(paths) ? paths.filter(p => imageAllowed(p, type)) : [];
    if (!safe.length) {
      empty(target, 'Preview not published yet', 'A selected work sample will appear here after it has been reviewed for public sharing.');
      return;
    }
    safe.forEach((path, i) => {
      const fig = el('figure', 'preview-page');
      const im = el('img');
      im.src = path;
      im.alt = `${captionBase}, preview page ${i + 1}`;
      im.loading = i < 1 ? 'eager' : 'lazy';
      im.decoding = 'async';
      im.addEventListener('error', () => {
        fig.replaceChildren(el('p', 'privacy-note', 'This preview image could not be loaded. Check the filename and uploaded path.'));
      });
      fig.appendChild(im);
      fig.appendChild(el('figcaption', '', `${captionBase} · Page ${i + 1} of ${safe.length}`));
      target.appendChild(fig);
    });
  }
  function initCategory() {
    const key = q.get('category');
    const group = Object.hasOwn(categories, key) ? categories[key] : null;
    const title = document.getElementById('category-title');
    const subtitle = document.getElementById('category-description');
    const target = document.getElementById('project-list');
    if (!group) {
      title.textContent = 'Pillar not found';
      subtitle.textContent = 'Choose one of the four pillars from the home page.';
      return;
    }
    title.textContent = group.title;
    subtitle.textContent = group.description;
    document.title = `${group.title} | Daniel Alvia`;
    const projects = Array.isArray(group.projects) ? group.projects : [];
    if (!projects.length) {
      empty(target, 'Work samples are being prepared', 'Projects for this pillar will appear here when selected previews are ready to share publicly.');
      return;
    }
    projects.forEach(project => {
      if (!/^[a-z0-9-]+$/.test(project.id || '')) return;
      const item = el('article', 'project-entry');
      const images = Array.isArray(project.previewImages) ? project.previewImages : [];
      const first = images.find(p => imageAllowed(p, 'project'));
      if (first) {
        const thumb = el('img', 'project-cover');
        thumb.src = first;
        thumb.alt = `${project.title || 'Project'} preview`;
        thumb.loading = 'lazy';
        item.appendChild(thumb);
      } else {
        item.appendChild(el('div', 'project-cover-blank', 'Selected work sample'));
      }
      const details = el('div', 'project-details');
      if (Array.isArray(project.tools) && project.tools.length) appendText(details, 'span', 'project-meta', project.tools.join(' · '));
      appendText(details, 'h2', '', project.title);
      appendText(details, 'p', '', project.description);
      const link = el('a', 'project-open', 'View project and previews →');
      link.href = `project.html?category=${encodeURIComponent(key)}&id=${encodeURIComponent(project.id)}`;
      details.appendChild(link);
      item.appendChild(details);
      target.appendChild(item);
    });
  }
  function initProject() {
    const key = q.get('category');
    const id = q.get('id');
    const group = Object.hasOwn(categories, key) ? categories[key] : null;
    const project = group && Array.isArray(group.projects) ? group.projects.find(p => p.id === id) : null;
    const target = document.getElementById('case-content');
    const back = document.getElementById('category-back');
    if (group) {
      back.href = `projects.html?category=${encodeURIComponent(key)}`;
      back.textContent = `← ${group.title}`;
    }
    if (!project) {
      empty(target, 'Project not found', 'This project may not be published yet, or the link may be outdated.');
      return;
    }
    document.title = `${project.title} | Daniel Alvia`;
    const layout = el('div', 'case-layout');
    const content = el('div');
    appendText(content, 'p', 'eyebrow', group.title);
    appendText(content, 'h1', 'case-title', project.title);
    appendText(content, 'p', 'case-description', project.description);
    if (project.context) {
      content.appendChild(el('h2', 'case-heading', 'The objective'));
      appendText(content, 'p', 'case-description', project.context);
    }
    if (project.approach) {
      content.appendChild(el('h2', 'case-heading', 'My approach'));
      appendText(content, 'p', 'case-description', project.approach);
    }
    if (Array.isArray(project.highlights) && project.highlights.length) {
      content.appendChild(el('h2', 'case-heading', 'Selected takeaways'));
      const list = el('ul', 'case-points');
      project.highlights.forEach(h => list.appendChild(el('li', '', String(h))));
      content.appendChild(list);
    }
    const sidebar = el('aside', 'case-sidebar');
    sidebar.appendChild(el('h2', '', 'Project details'));
    if (project.role) {
      sidebar.appendChild(el('p', 'side-label', 'My role'));
      sidebar.appendChild(el('p', 'side-value', project.role));
    }
    if (Array.isArray(project.tools) && project.tools.length) {
      sidebar.appendChild(el('p', 'side-label', 'Tools & skills'));
      sidebar.appendChild(el('p', 'side-value', project.tools.join(', ')));
    }
    sidebar.appendChild(el('p', 'side-label', 'Access'));
    sidebar.appendChild(el('p', 'side-value', 'Public image previews only; original working documents are not hosted on this website.'));
    layout.append(content, sidebar);
    target.appendChild(layout);
    const previewIntro = el('div', 'preview-intro');
    previewIntro.appendChild(el('h2', '', 'Selected work previews'));
    previewIntro.appendChild(el('p', '', 'Pages are purposefully selected and watermarked. They are not the original editable files.'));
    target.appendChild(previewIntro);
    const gallery = el('div', 'preview-stack');
    previewGallery(gallery, project.previewImages, project.title, 'project');
    target.appendChild(gallery);
    target.appendChild(el('p', 'privacy-note', 'Public preview images can still be saved or captured by visitors. Only share material that you are comfortable making public.'));
  }
  function initResume() {
    const target = document.getElementById('resume-images');
    const images = window.RESUME_PREVIEW_IMAGES;
    if (!Array.isArray(images) || !images.length) {
      empty(target, 'Résumé preview coming soon', 'A selected, reviewed résumé preview will be shown here. In the meantime, please request the résumé by email.');
      return;
    }
    previewGallery(target, images, 'Résumé preview', 'resume');
  }
  window.PortfolioSite = Object.freeze({ initCategory, initProject, initResume });
})();
