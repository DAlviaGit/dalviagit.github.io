/* PUBLIC metadata only. Never store private file URLs, passwords, tokens or original documents here.

HOW TO ADD A REAL PROJECT:
1. In your PRIVATE repository, prepare and check 1-3 preview images, e.g.:
   assets/previews/valuation-report/01.webp
   assets/previews/valuation-report/02.webp
2. Copy ONLY those reviewed .webp images to PUBLIC_SITE/assets/previews/valuation-report/.
3. Add this entry inside the right category's projects: [ ] array (remove the // lines):
   {
     id: "valuation-report", // unique lowercase ID, letters/numbers/hyphens only
     title: "Company Valuation Research",
     description: "A short description of the real work, without confidential details.",
     context: "What problem the project addressed.",
     approach: "How you approached the problem and tools you used.",
     highlights: ["One verifiable takeaway", "Another verified takeaway"],
     tools: ["Excel"],
     role: "Your actual role",
     previewImages: [
       "assets/previews/valuation-report/01.webp",
       "assets/previews/valuation-report/02.webp"
     ]
   }

Your current project lists are deliberately empty; no school projects or results were invented.
*/
window.PORTFOLIO = {
  finance: {
    title: "Finance & Valuation",
    description: "Valuation work, financial analysis, and investment research.",
    projects: []
  },
  analytics: {
    title: "Business Analytics",
    description: "Data analysis, dashboards, and practical decision making.",
    projects: []
  },
  marketing: {
    title: "Marketing Strategy",
    description: "Positioning, consumer insights, and marketing recommendations.",
    projects: []
  },
  operations: {
    title: "Operations & Information Technology",
    description: "Information systems, process design, and operational decisions.",
    projects: []
  }
};

/* Résumé preview files. Put approved, watermarked .webp images here after review.
   Example: ["assets/resume/01.webp", "assets/resume/02.webp"] */
window.RESUME_PREVIEW_IMAGES = [];
