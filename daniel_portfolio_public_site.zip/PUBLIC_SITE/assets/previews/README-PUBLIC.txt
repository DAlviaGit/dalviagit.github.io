Place only reviewed, watermarked WEBP preview images here. Never publish original documents.
