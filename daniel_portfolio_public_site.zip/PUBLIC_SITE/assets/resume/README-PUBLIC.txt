Place reviewed, watermarked résumé WEBP preview images here. Original résumé stays private.
